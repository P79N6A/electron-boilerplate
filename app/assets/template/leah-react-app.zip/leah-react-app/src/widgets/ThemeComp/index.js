/**
 *  主题管理器组件, 任何地方可以使用
 * 
 *  CODE:
 *      <ThemeComp />
*/

import React from 'react'
import { connect } from 'react-redux'
import { Divider, Drawer, Tooltip, Switch, Button } from 'antd';
import { ErrorReporter } from '@tencent/leah-ui';
import { ColorButton, SwitchRow, ThemeGroup, DrawerButton } from './Styleds';
import ThemeBtn from './ThemeBtn'
import ThemeManager from '@/utils/ThemeManager'

const mapState = (state) => state.layout;
const mapDispatch = dispatch => {
    const { setLsState, changeThemeColor, changeColorWeak } = dispatch.layout;

    return {
        setLayoutState: setLsState,
        changeColorWeak, changeThemeColor,
    }
}

@ErrorReporter
@connect(mapState, mapDispatch)
export default class ThemeComp extends React.Component {

    // 颜色按钮组
    getColorBtns() {
        const { changeThemeColor } = this.props;

        const colorBtns = [];
        ThemeManager.map('THEME_COLOR', color => {
            colorBtns.push(
                <Tooltip key={color} title={ThemeManager.getColorName(color)}>
                    <ColorButton color={color} onClick={() => changeThemeColor({ themeColor: color })} />
                </Tooltip>
            )
        });

        return colorBtns;
    }

    render() {
        const {
            drawerVisible, headMenuTheme, sideMenuTheme,
            fistInHead, contentBGWhite, setLayoutState
        } = this.props;

        return (
            <span>
                <DrawerButton>
                    <Button
                        icon="skin" size="large" type="primary"
                        onClick={e => setLayoutState({ drawerVisible: true })}
                    ></Button>
                </DrawerButton>

                <Drawer
                    title="主题设置" placement="right"
                    onClose={() => setLayoutState({ drawerVisible: false })}
                    visible={drawerVisible}
                >
                    <h4>颜色</h4>
                    <ThemeGroup height="30px">
                        {this.getColorBtns()}
                    </ThemeGroup>

                    <Divider />

                    <h4>基础配置</h4>
                    <SwitchRow>
                        一级菜单置顶：
                                <Switch
                            size="small"
                            checked={fistInHead}
                            onChange={fistInHead => setLayoutState({ fistInHead })}
                        />
                    </SwitchRow>

                    <SwitchRow>
                        content白色背景：
                                <Switch
                            size="small"
                            checked={contentBGWhite}
                            onChange={contentBGWhite => setLayoutState({ contentBGWhite })}
                        />
                    </SwitchRow>

                    <Divider />

                    <h4>主题搭配</h4>
                    <ThemeGroup height="70px">
                        {
                            ThemeManager.getThemeNames().map(name => {
                                return (
                                    <ThemeBtn
                                        key={name} themeName={name}
                                        value={{ headMenuTheme, sideMenuTheme }}
                                        onChange={menuTheme => setLayoutState({ ...menuTheme })}
                                    />
                                )
                            })
                        }
                    </ThemeGroup>
                </Drawer>

            </span>
        )
    }
}