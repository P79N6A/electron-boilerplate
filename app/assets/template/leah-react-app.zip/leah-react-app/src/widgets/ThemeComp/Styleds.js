import styled from 'styled-components'

export const DrawerButton = styled.div`
    position: fixed;
    bottom: 20px;
    right: -1px;
    
    && button{
        border-radius: 50% 0 0 50%;
    }
`

export const ColorButton = styled.span`
    && {
        background-color: ${props => props.color};
    }
    display: inline-block;
    width: 23px;
    height: 23px;
    border-radius: 50%;
    margin: 0 4px;
    cursor: pointer;
`

export const ThemeGroup = styled.div`
    display: flex;
    align-items: center;
    height: ${props => props.height};
`

export const SwitchRow = styled.div`
    display: flex;
    justify-content: space-between;
    margin-bottom: 16px;
`

