import React from 'react';
import { Icon } from 'antd';
import styled from 'styled-components'
import isEqual from 'lodash/isEqual'
import ThemeManager from '@/utils/ThemeManager'

const ConComp = styled.div`
    height: 45px;
    width: 60px;
    box-shadow: 0 3px 3px rgba(0,21,41, 0.5);
    border-radius: 0px;
    border: 2px solid #333;
    overflow: hidden;
    margin: 4px;
    display: flex;
    flex-direction: column;
    cursor: pointer;

    && {
        .head {
            height: 10px;
            background-color: ${props => props.handBgColor};
        }
        .body {
            flex:1;
            display: flex;
            background-color: #f0f2f5;
            .sider {
                width: 15px;
                background-color: ${props => props.menuBgColor}
            }
            .content {
                flex: 1;
                display: flex;
                justify-content: center;
                align-items: center;
                color: ${props => props.theme.prColor};
            }
        }
    }
`

const ThemeBtn = ({ themeName, value, onChange }) => {
    const config = ThemeManager.getThemeConfig(themeName)
    const themeColors = ThemeManager.getThemeColors(themeName)
    const isChosen = isEqual(value, config)

    return (
        <ConComp {...themeColors} onClick={e => onChange(config)}>
            <div className="head"></div>
            <div className="body">
                <div className="sider"></div>
                <div className="content">
                    {isChosen && <Icon type="heart" theme="twoTone" />}
                </div>
            </div>
        </ConComp>
    )
}


export default ThemeBtn 