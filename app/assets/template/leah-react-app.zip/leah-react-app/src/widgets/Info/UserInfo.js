import React from 'react'
import ppo from 'ppo'
import styled from 'styled-components'
import { Avatar, Divider, Popover } from 'antd'

const Con = styled.div`
    float: right;
    cursor: pointer;
`

export default class UserInfo extends React.Component {

    constructor(props) {
        super(props);

        this.exit = this.exit.bind(this);
    }

    exit(e) {
        ppo.delCookie('leah_auth');
        ppo.delCookie('leah_user');
        
        const url = window.location.href.split('?')[0];
        const href = `http://passport.oa.com/modules/passport/signout.ashx?url=${encodeURIComponent(url)}`;
        window.location.href = href;
    }

    render() {
        const data = this.props.data || {};

        const content = (
            <div><a onClick={this.exit}>退出</a></div>
        );

        return (
            <Popover content={content}>
                <Con>
                    <Avatar size="small" icon="user" src={data.avatar} />
                    <Divider type="vertical" />
                    {data.user}
                </Con>
            </Popover>
        )
    }
}