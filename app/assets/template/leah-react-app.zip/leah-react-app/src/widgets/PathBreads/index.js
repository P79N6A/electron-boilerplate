import React from 'react'
import styled from 'styled-components'
import { Breadcrumb, Icon } from 'antd'
const { Item } = Breadcrumb

const StBreadcrumb = styled(Breadcrumb)`
    &&{
        margin: 16px; 
    }
`

const PathBreads = ({ paths = [] }) => {
    return (
        <StBreadcrumb>
            {paths.map(item => {
                const { name, icon } = item
                return (
                    <Item key={name}>
                        {icon && <Icon type={icon} />}
                        <span>{name}</span>
                    </Item>
                )
            })}
        </StBreadcrumb>
    )
}

export default PathBreads