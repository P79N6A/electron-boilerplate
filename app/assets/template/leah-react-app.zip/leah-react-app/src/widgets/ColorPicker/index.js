import React from 'react'
import { Popover } from 'antd'
import { SketchPicker } from 'react-color'
import './style.less'

const ColorPicker = ({ value = '#fff', onChange = () => { } }) => {

    const content = <SketchPicker color={value}
        onChangeComplete={color => {
            const { hex, rgb } = color
            const cssColor = hex && `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${rgb.a})`
            onChange(cssColor)
        }} />

    return (
        <Popover
            trigger="click"
            placement="bottom" 
            title="自定义主题颜色"
            overlayClassName="colorPicker-pop"
            content={content}
        >
            <div className="colorPicker">
                <span className="red"></span>
                <span className="green"></span>
                <span className="blue"></span>
                <span className="yellow"></span>
            </div>
        </Popover>
    )
}

export default ColorPicker