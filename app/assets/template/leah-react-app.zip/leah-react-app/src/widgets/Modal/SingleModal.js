/**
 *  单一全局对话框组件
 * 
 * CODE:
 *      import SingleModal from '@/widgets/Modal/SingleModal';
 * 
 *      --- 方式1：实例式用法，可以使用多个浮窗。
 * 
        this.modal = new SingleModal({
            content: <div><h1>xxxxx</h1></div>,
            closable: false,
            maskClosable: false
        });

        /...
        this.modal.show({ content: 'hello world' });

        this.modal.hide();


 *      --- 方式2：静态方法用法，全局唯一浮窗。
 * 
        // SingleModal.init({...}); 非必须方法

        /...
        SingleModal.show({
            content: <div><h1>xxxxx</h1></div>,
            closable: false,
            maskClosable: false
        });

        SingleModal.hide();
*/

import React from 'react'
import ReactDOM from 'react-dom'
import { Modal } from 'antd';

let index = 0;
export default class SingleModal {

    static singleModal = null;

    static init(config) {
        if (!this.singleModal) this.singleModal = new SingleModal(config);
    }

    static show(config) {
        if (!this.singleModal) this.init(config);
        this.singleModal.show(config);
    }

    static hide() {
        this.singleModal && this.singleModal.hide();
    }

    constructor(config) {
        this.config = { ...config };
        this.added = false;

        this.modal = null;
    }

    add() {
        if (this.added) return;

        this.added = true;

        const dom = document.createElement('div');
        dom.id = `leah_single_modal_${index++}`;
        document.querySelector('body').appendChild(dom);

        ReactDOM.render(
            <ParentModal onRef={ref => this.modal = ref}>{this.content}</ParentModal>,
            dom);
    }

    show(config) {
        this.add();
        this.modal.show(config || this.config);
    }

    hide() {
        this.modal && this.modal.hide();
    }
}

// 父容器
class ParentModal extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            ext: null,
            content: null,
            visible: false
        }
    }

    componentDidMount() {
        this.props.onRef(this);

        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
    }

    show({ content, ...ext }) {
        this.setState({ visible: true, content, ext });
    }

    hide() {
        this.setState({ visible: false });
    }

    showModal() {
        const { ext = {}, content } = this.state;
        ext.onOk && ext.onOk(content);
        this.setState({ visible: false });
    }

    hideModal() {
        const { ext = {}, content } = this.state;
        ext.onCancel && ext.onCancel(content);
        this.setState({ visible: false });
    }

    render() {
        const { visible, content, ext } = this.state;
        const newExt = Object.assign({}, ext);
        delete newExt.onOk;
        delete newExt.onCancel;

        return <Modal
            onOk={this.showModal}
            onCancel={this.hideModal}
            visible={visible}
            {...newExt}
        >
            {content}
        </Modal>
    }
}