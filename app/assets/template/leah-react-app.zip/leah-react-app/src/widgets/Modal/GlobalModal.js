// 全局对话框组件

import React from 'react'
import ReactDOM from 'react-dom'
import cloneDeep from 'lodash/cloneDeep'

// 默认状态
const DEFAULT_STATE = {
    Modal: null, // 弹窗组件
    visible: false, // 弹窗是否可见
    onOk: () => { }, // 确定回调
    onCancel: () => { }, // 取消回调
    extProps: {} // 其他透传属性
}

class DavModal extends React.PureComponent {

    state = cloneDeep(DEFAULT_STATE)

    componentDidMount() {
        this.props.onRef(this) // 保存引用
    }

    // 打开弹窗
    show = ({ Modal, onOk, onCancel, ...extProps }) => this.setState({
        Modal, onOk, onCancel, extProps, visible: true
    })

    // 确定回调， params：弹窗内部要向外传递的参数
    handleOk = (params) => {
        const { onOk } = this.state
        onOk && onOk(params)
        this.setState(cloneDeep(DEFAULT_STATE))
    }

    // 取消回调， params：弹窗内部要向外传递的参数
    handleCancel = (params) => {
        const { onCancel } = this.state
        onCancel && onCancel(params)
        this.setState(cloneDeep(DEFAULT_STATE))
    }

    render() {
        const { Modal, visible, extProps } = this.state

        return Modal ?
            <Modal
                {...extProps}
                visible={visible}
                onOk={this.handleOk}
                onCancel={this.handleCancel}
            /> : null
    }
}

const init = () => {
    let modal // 对话框组件实例引用

    const dom = document.createElement('div');
    dom.id = "leah_global_modal";
    document.querySelector('body').appendChild(dom)
    ReactDOM.render(<DavModal onRef={ref => modal = ref} />, dom)

    return modal
}

export default init()