/**
 *  ECharts React组件，使用及其简单
 * 
 *  依   赖: echart4.2.0  http://echarts.baidu.com/
 *  参考文章: https://segmentfault.com/a/1190000008049240
 * 
 *  注： 你用到了什么echarts组件需要导入进来  － import 'echarts/lib/chart/radar'; 也可以在外部导入;
 * 
 *  CODE:
 *      <ECharts theme='light' option={this.getBarOption()} height={400} />
 * 
 *      // 附带动画
 *      <ECharts animate={this.animate.bind(this)} option={data} height={400} />
*/

import React from 'react'
import delay from '@/utils/delay';
import RAFManager from 'raf-manager';

// 默认导入了几种常用的图表ui, 如果您还用到其他的图表ui请对应导入
import echarts from 'echarts/lib/echarts';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/title';
import 'echarts/lib/component/markPoint';

import 'echarts/lib/chart/bar';
import 'echarts/lib/chart/line';
import 'echarts/lib/chart/bar';
import 'echarts/lib/chart/pie';

import 'echarts/lib/chart/gauge';
import 'echarts/lib/chart/pictorialBar';

// import 'echarts/lib/chart/map';
// import 'echarts/lib/chart/treemap';
// import 'echarts/lib/chart/graph';
// import 'echarts/lib/chart/gauge';
// import 'echarts/lib/chart/funnel';
// import 'echarts/lib/chart/parallel';
// import 'echarts/lib/chart/sankey';
// import 'echarts/lib/chart/boxplot';
// import 'echarts/lib/chart/candlestick';
// import 'echarts/lib/chart/effectScatter';
// import 'echarts/lib/chart/lines';
// import 'echarts/lib/chart/heatmap';
// import 'echarts/lib/component/graphic';
// import 'echarts/lib/component/grid';
// import 'echarts/lib/component/legend';

// import 'echarts/lib/component/polar';
// import 'echarts/lib/component/geo';
// import 'echarts/lib/component/parallel';
// import 'echarts/lib/component/singleAxis';
// import 'echarts/lib/component/brush';

// import 'echarts/lib/component/dataZoom';
// import 'echarts/lib/component/visualMap';

// import 'echarts/lib/component/markPoint';
// import 'echarts/lib/component/markLine';
// import 'echarts/lib/component/markArea';

// import 'echarts/lib/component/timeline';
// import 'echarts/lib/component/toolbox';

// import 'zrender/lib/vml/vml';

export default class ECharts extends React.Component {

    constructor(props) {
        super(props);

        this.chart = null;
        this.dispose = false;
        this.myRef = React.createRef();
        this.resize = this.resize.bind(this);
    }

    async componentDidMount() {
        await this.drawCharts(this.props);
    }

    async componentWillReceiveProps(nextProps) {
        await this.drawCharts(nextProps);
    }

    async drawCharts(props) {
        const { option } = props;
        if (!option) return console.error("++++++ 请输入option ++++++");

        await delay(100);

        if (this.dispose) return;
        this.createEchartsIns(props);
        this.chart.setOption(option);
        this.resize();
    }

    createEchartsIns(props) {
        if (this.chart) return;
        if (!this.myRef.current) return;

        const { theme, opts, autoSize = true, animate, fps = 2 } = props;
        this.chart = echarts.init(this.myRef.current, theme, opts);

        if (autoSize) window.addEventListener('resize', this.resize, false);
        if (animate) RAFManager.add(animate, fps, this.chart);
    }

    componentWillUnmount() {
        const { animate } = this.props;

        RAFManager.remove(animate);
        window.removeEventListener('resize', this.resize, false);
        if (this.chart) this.chart.dispose();
        this.dispose = true;
    }

    resize() {
        if (!this.chart) return;
        this.chart.resize();
    }

    render() {
        const { width = '100%', height = 250 } = this.props;

        return (
            <div ref={this.myRef} style={{ width, height }}></div>
        )
    }
}