import React from 'react'
import { Form, Row, Col, Button, Icon, Divider } from 'antd'
import styled from 'styled-components'

const FormWithSt = styled(Form)`
    && .ant-form-item {
        display: flex;
        margin-bottom: 24px;
        margin-right: 0;
    }
    && .ant-form-item-control-wrapper {
        flex: 1;
    }
`

@Form.create({
    mapPropsToFields({ data = {} }) {
        const fields = {}
        for (const key in data) {
            fields[key] = Form.createFormField({ ...data[key] })
        }
        return fields
    },
    onFieldsChange(props, changedFields) {
        props.onChange(changedFields)
    },
})
export default class FilterForm extends React.PureComponent {
    state = {
        showMore: false // 是否展开
    }

    toggle = () => {
        this.setState({ showMore: !this.state.showMore })
    }

    handleReset = () => {
        this.props.form.resetFields()
    }

    render() {
        const { rowGutter = 24, colSpan = 6, items = [], form, onSubmit } = this.props
        const { showMore } = this.state
        const { getFieldDecorator } = form
        const hideCount = rowGutter / colSpan - 1
        return (
            <FormWithSt layout={'inline'} onSubmit={e => onSubmit(e, form)}>
                <Row gutter={rowGutter}>
                    {items.map((item, index) => {
                        const { id, rules, input, span = colSpan, ...itemProps } = item
                        return (
                            <Col
                                key={id} span={span}
                                style={{ display: showMore || index < hideCount ? 'block' : 'none' }}
                            >
                                <Form.Item {...itemProps}>
                                    {getFieldDecorator(id, { rules })(input)}
                                </Form.Item>
                            </Col>
                        )
                    })}

                    <Col
                        span={showMore ? rowGutter : colSpan}
                        style={{ textAlign: showMore ? 'right' : 'left' }}
                    >
                        <Form.Item>
                            <Button type="primary" icon="search" htmlType="submit">查询</Button>
                            <Divider type="vertical" />
                            <Button type="danger" icon="delete" onClick={this.handleReset}>重置</Button>
                            <Divider type="vertical" />
                            <a onClick={this.toggle}>
                                {showMore ? '收起' : '展开'}
                                < Icon type={showMore ? 'up' : 'down'} />
                            </a>
                        </Form.Item>
                    </Col>
                </Row>
            </FormWithSt>
        )
    }
}
