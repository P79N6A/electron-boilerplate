import React from 'react'
import { Form } from 'antd'

@Form.create({
    mapPropsToFields({ data = {} }) {
        const fields = {}
        for (const key in data) {
            fields[key] = Form.createFormField({ ...data[key] })
        }
        return fields
    },
    onFieldsChange(props, changedFields) {
        props.onChange && props.onChange(changedFields)
    },
})
export default class EasyForm extends React.PureComponent {
    render() {
        const { items, form, layout, onSubmit } = this.props
        const { getFieldDecorator } = form
        // 默认horizontal布局
        const itemLayout = layout === 'horizontal' ? {
            labelCol: { span: 4 },
            wrapperCol: { span: 20 },
        } : null

        return (
            <Form layout={layout} onSubmit={e => onSubmit(e, form)}>
                {items.map(item => {
                    const { id, rules, input, valuePropName = 'value', before, after, ...itemProps } = item
                    return (
                        <Form.Item key={id} {...itemLayout} {...itemProps} >
                            {before}
                            {getFieldDecorator(id, { rules, valuePropName })(input)}
                            {after}
                        </Form.Item>
                    )
                })}
            </Form>
        )
    }
}
