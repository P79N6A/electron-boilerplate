import React from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { Menu, Icon } from 'antd'
const { Item, SubMenu } = Menu

const StMenu = styled(Menu)`
    &&&.ant-menu.ant-menu-dark .ant-menu-item-selected, 
    .ant-menu-submenu-popup.ant-menu-dark .ant-menu-item-selected {
        border-bottom: none;
    }
    &.ant-menu-dark, &.ant-menu-dark .ant-menu-sub {
        color: rgba(255, 255, 255, 0.65);
        background: #222222;
    }
    &.ant-menu-dark .ant-menu-inline.ant-menu-sub {
        background: #333333;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25) inset;
    }
`

// 菜单项目
const menuItems = (menus) => menus.map(item => {
    const { name, icon = 'bars', path, children } = item
    const title = (
        <span>
            <Icon type={icon} />
            <span>{name}</span>
        </span>
    )
    if (children) {
        return (
            <SubMenu key={name} title={title}>
                {menuItems(children)}
            </SubMenu>
        )
    } else {
        return (
            <Item key={path}>
                <Link to={path}>{title}</Link>
            </Item>
        )
    }
})

class SiderMenu extends React.PureComponent {
    state = {
        openKeys: this.props.openKeys || []
    }

    componentWillReceiveProps(nextProps) {
        const { openKeys, collapsed } = nextProps
        if (openKeys.length > 0) {
            this.setState({ openKeys })
        }
        if (collapsed) {
            this.setState({ openKeys: [] })
        }
    }

    render() {
        const {
            menus = [], pathname = '', theme = 'dark',
        } = this.props
        const { openKeys } = this.state

        return (
            <StMenu
                mode="inline"
                theme={theme}
                openKeys={openKeys}
                onOpenChange={openKeys => this.setState({ openKeys })}
                selectedKeys={[pathname]}
            >
                {menuItems(menus)}
            </StMenu>
        )
    }
}

export default SiderMenu