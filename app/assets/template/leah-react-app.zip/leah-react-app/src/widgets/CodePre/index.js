import React from 'react';
import styled from 'styled-components';

const Pre = styled.pre`
    background: #002a35;
    color: #29a28e;
    text-decoration: none;
    border: 0;
`;

const Code = styled.code`
    background: #002a35;
    color: #29a28e;
    text-decoration: none;
    border: 0;
`;

export default class CodePre extends React.PureComponent {

    render() {
        const { children, height = 250, width = "100%" } = this.props;
        const formatChildren = typeof children === 'string' ? children : JSON.stringify(children, null, 2);

        return (
            <Pre style={{ width, height }}>
                <Code>
                    {formatChildren}
                </Code>
            </Pre>
        )
    }
}