import styled from 'styled-components'

export const Con = styled.div`
    line-height: 0;
    display: flex;
    align-items: center;
`;

export const Thumb = styled.div`
    line-height: 0;
    display: flex;
    align-items: center;
    width: 40px;
    height: 30px;
    line-height: 0;
    font-size: 39px;
    position: relative;
    margin-right: 5px;
    cursor: pointer;
    
        .thumbnails-icon {
            position: absolute;
            top: -5px;
        }

        .thumbnails-img {
            width: 100%;
            height: 100%;
        }
`
