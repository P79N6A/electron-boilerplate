/**
 *  此组件为CMS业务专属上传组件，使用的是架平(新闻)上传接口。
 *  
 *  接口文档: http://tapd.oa.com/article_pool/markdown_wikis/view/#1010157321007066361
 * 
 *  用   法: 
 *      1.  <CmsUpload onChange={onChange} onStart={onStart}/>
 *      2.  <CmsUpload>
 *              <Button> <Icon type="upload" /> 上传头像 </Button>
 *          </CmsUpload>
 *      
 *      3.  const url = 'http://img.cms.webdev.com/interface/image/imageMultiUpload4CustomSize.php';
 *          const data = { size:'[{"width":500,"height":500,"quality":0, "zoom":1}]' };
 *          <CmsUpload url={url} data={data}/>
 *
*/

import React from 'react';
import get from 'lodash/get';
import { Con, Thumb } from './styled'
import { Popover, Button, Icon } from 'antd';
import CrossDomainPost from '../../utils/CrossDomainPost';

export default class CmsUpload extends React.Component {

    constructor(props) {
        super(props);

        this.value = null;
        this.upload = this.upload.bind(this);
        this.onClick = this.onClick.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    componentDidMount() {
        this.form = CrossDomainPost.createFileForm();
        this.fileInput = this.form.querySelector('.ifp-file');
        this.fileInput.name = 'Filedata';
        this.fileInput.addEventListener('change', this.onChange, false);
    }

    componentWillUnmount() {
        this.fileInput.removeEventListener('change', this.onChange);
    }

    upload(file) {
        const { url, data, onSuccess, onStart, onError, onChange } = this.props;
        onStart && onStart();

        const params = {
            data: Object.assign({
                'appkey': '1',
                'of': 'jsonjs'
            }, data),
            url: url || '//img.cms.webdev.com/interface/image/imageOrginalUpload.php',
            domain: 'webdev.com',
            timeout: 300000,
            form: this.form,
            postMessage: true,
            success(res) {
                this.value = get(res, 'data.url');

                onChange && onChange(this.value);
                onSuccess && onSuccess(this.value);
                this.setState({});
            },
            error() {
                onError && onError();
            }
        };

        params.success = params.success.bind(this);
        params.error = params.error.bind(this);
        CrossDomainPost.send(params);
    }

    onChange(e) {
        const files = e.target.files;
        if (!files || !files.length) return;

        const file = files[0];
        this.upload(file);
    }

    onClick() {
        if (this.fileInput) this.fileInput.click();
    }

    getThumb() {
        if (this.value) {
            const content = <img src={this.value} alt="预览" style={{ height: 80 }} />;

            return (
                <Thumb>
                    <Popover content={content} title="预览">
                        <img alt="缩略图" className='thumbnails-img' src={this.value} />
                    </Popover>
                </Thumb>
            )
        } else {
            return (<Thumb><Icon className='thumbnails-icon' type="picture" /></Thumb>)
        }
    }

    getChildren() {
        return this.props.children ? this.props.children : (<Button><Icon type="upload" /> 上传</Button>);
    }

    render() {
        return (
            <Con>
                {this.getThumb()}
                <span onClick={this.onClick}>
                    {this.getChildren()}
                </span>
            </Con>
        )
    }
}