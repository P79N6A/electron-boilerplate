import React from 'react'
import styled from 'styled-components'

const Cycles = styled.div`
    width: 40px;
    height: 40px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    >div {
        display: flex;
        justify-content: space-between;
        >span {
            width: 10px;
            height: 10px;
            border-radius: 5px;
            background-color: ${props => props.theme.prColor}; 
        }
    }
`
const Item = ({ className }) => {
    return (
        <Cycles className = { className }>
            <div><span /><span /></div>
            <div><span /><span /></div>
        </Cycles>
    )
}

const Wrapper = styled.div`
    z-index: 9999999;
    position: relative;
    width: 40px;
    height: 40px;
    >div{
        position: absolute;
        top: 0;
        left: 0;
    }
    >.rotate {
        transform: rotate(45deg);
    }
`
const Loading = () => (
    <Wrapper>
        <Item />
        <Item className="rotate" />
    </Wrapper>
)

export default Loading